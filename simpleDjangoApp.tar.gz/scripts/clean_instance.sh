#!/usr/bin/env bash
rm -rf /home/ec2-user/myApplication/*