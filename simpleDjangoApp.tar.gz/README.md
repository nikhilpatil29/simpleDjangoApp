# Example-DjangoApp
Sample Django Application Used for Distelli Tutorial 
## To Run the Application, use the following command:
  
    python manager.py runserver
# simpleDjangoApp
